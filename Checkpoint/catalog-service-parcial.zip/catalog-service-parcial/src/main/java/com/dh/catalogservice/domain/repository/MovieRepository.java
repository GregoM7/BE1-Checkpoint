package com.dh.catalogservice.domain.repository;

public interface MovieRepository {
}
