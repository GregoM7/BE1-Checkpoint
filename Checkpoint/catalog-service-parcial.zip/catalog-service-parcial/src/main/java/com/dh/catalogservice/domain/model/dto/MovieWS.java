package com.dh.catalogservice.domain.model.dto;

public class MovieWS {
}
