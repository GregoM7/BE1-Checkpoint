package com.dh.catalogservice.api.service;

public interface CatalogService {
}
